# CIR Consultation Service — migration notes

This archive contains the tracked application source and public website assets, plus this setup guide. It does not contain the Replit workspace configuration/history, local dependencies or build output, uploaded reference files, unrelated ad exports, database contents/backups, or credential values. The original project files were not modified.

## Contents and stack

- `artifacts/cir-website`: React 19 + Vite + Tailwind website and customer/admin portals.
- `artifacts/api-server`: Express 5 / TypeScript API, mounted at `/api`.
- `lib/db`: PostgreSQL schema/client using Drizzle ORM.
- `lib/api-spec`, `lib/api-zod`, `lib/api-client-react`: API specification and generated clients.
- `scripts`: operational scripts. In this archive only, the demo seeder is sanitized: it requires fresh passwords supplied through `SEED_OWNER_PASSWORD`, `SEED_MANAGER_PASSWORD`, `SEED_EXECUTIVE_PASSWORD`, and `SEED_CUSTOMER_PASSWORD`, and refuses to run with `NODE_ENV=production`.
- Other tracked workspace artifacts, shared libraries, TypeScript configuration, pnpm lockfile, and public app assets.

The uploaded `attached_assets/` files and `exports/instagram-ads/` are not imported by the website source and are omitted. They include user-provided reference material or generated marketing images, not deploy-time website assets. The tracked assets under `artifacts/cir-website/public/` are included.

## Host prerequisites

- Node.js 22.12+ or 24.x, and pnpm. This archive is configured for the pnpm 11 install environment shown in your hosting error; the project intentionally requires pnpm, not npm/yarn.
- A PostgreSQL database with SSL/network access from the API host.
- A static host for the Vite build and a Node host for the API, or one host with a reverse proxy that routes `/api/*` to the API and all website paths to the static frontend. Keep the browser and API on the same HTTPS origin so the `HttpOnly` login cookie works.
- Persistent, private database backups and secure secret/environment-variable storage. Do not place real credentials in source, frontend `VITE_*` variables, or this archive.

## First setup

The root `package.json` explicitly permits the four existing workspace-approved dependency build scripts. This is needed by pnpm 11 hosts that do not honor the legacy workspace-only approval list. The dependency versions and lockfile are unchanged.


1. Extract the ZIP. From the project root, install the locked dependencies:

   ```sh
   corepack enable
   corepack prepare pnpm@11 --activate
   pnpm install --frozen-lockfile
   ```

2. Create a **new empty** PostgreSQL database and set `DATABASE_URL` for the API and schema tools. Do not point the schema tool at valuable production data without reviewing/backing it up first.
3. Run the schema push only against the intended database, after reviewing the schema and making a backup if it already contains data:

   ```sh
   pnpm --filter @workspace/db run push
   ```

4. Configure the API environment variables below in the host's secret manager.
5. Build the API and frontend:

   ```sh
   pnpm --filter @workspace/api-server run build
   NODE_ENV=production PORT=8080 pnpm --filter @workspace/api-server run start
   BASE_PATH=/ PORT=5173 NODE_ENV=production pnpm --filter @workspace/cir-website run build
   ```

   The API build/start commands are separate from the static frontend build; the current Express server does not serve the built frontend itself. Publish `artifacts/cir-website/dist/public` from a static host and route `/api` on the same domain to the API process listening on port 8080. Set the host's API process command to `node --enable-source-maps artifacts/api-server/dist/index.mjs` after building.

6. Set the API's public callback origin to the final HTTPS website domain and configure matching payment notifications in the payment provider dashboard. Do not assume the previous Replit domain or callback settings remain usable after the move.
7. Run `pnpm run typecheck` from the root before deployment. Exercise registration/login, password reset/OTP, case/document flows, and successful/failed payment callbacks in a non-production environment first.

## Environment variables

Configure these on the **server only**; never commit values or expose them as frontend build-time variables.

| Name | Purpose |
| --- | --- |
| `DATABASE_URL` | PostgreSQL connection string; required by the API and schema tooling. |
| `PORT` | Host-assigned listening port for each process. |
| `NODE_ENV` | Set to `production` for the production API. |
| `BASE_PATH` | Vite requires a base path at build/dev time; use `/` when hosted at the domain root. |
| `PAYU_KEY` | PayU merchant key, if PayU is used. |
| `PAYU_SALT` | PayU merchant salt, if PayU is used. Keep it server-side. |
| `PAYU_CALLBACK_BASE_URL` | Final public HTTPS origin used to construct production PayU callback URLs (origin only, e.g. `https://example.com`). |
| `FAST2SMS_API_KEY` | Optional Fast2SMS credential for OTP delivery. Without it, this code falls back to development OTP behavior; do not expose that fallback publicly. |
| `ADMIN_OWNER_PASSWORD` | Optional owner-login override supported by the API. Set it only using the new host's secret manager if needed. |
| `LOG_LEVEL` | Optional API log level. |
| `SEED_OWNER_PASSWORD`, `SEED_MANAGER_PASSWORD`, `SEED_EXECUTIVE_PASSWORD`, `SEED_CUSTOMER_PASSWORD` | Required only to run the sanitized development demo seed script. Never use demo seed records on a live database. |

`SESSION_SECRET` is mentioned in an old collaborator note, but the current server source does not read it. Do not rely on that variable to protect the current sessions.

## Important security and deployment limitations

**Do not put this app directly on the public internet with customer/admin data until authentication is hardened.** The current code hashes passwords with plain SHA-256 plus a fixed source-code salt, keeps login sessions in an in-memory process-local map, and does not set the session cookie's `Secure` flag. These are significant weaknesses and can cause sessions to break on restarts or when running multiple API instances. Before production hosting, replace this with a maintained password-hashing algorithm (Argon2id/bcrypt), persistent signed/rotating sessions (database or Redis), secure cookie settings, CSRF/rate-limit protections, and a security review of authorization on every portal/API route.

The document upload handler stores base64 document content as database text. Database backups therefore contain potentially sensitive personal and financial records. Encrypt and tightly restrict backup/restore access; the archive does not include any database data.

The database is not migrated by this source ZIP. Export the old database separately over a secure channel, restore it to the new PostgreSQL host, validate counts and representative records, and only then switch traffic. Keep an untouched backup and rollback plan. Do not run the demo seed script against production.

The Vite configuration still references Replit developer tooling and workspace settings require `PORT` and `BASE_PATH`. Those are source/workspace assumptions, not hosted-site features; verify dependency installation and frontend builds on the target OS before launch. The workspace has optional native-binary overrides, so non-x86_64/Linux build hosts may require adjusting the package-manager configuration and regenerating the lockfile.
